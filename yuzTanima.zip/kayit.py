# -*- coding: utf-8 -*-
from PIL import Image
import numpy as np
import sys, os
import time
import cv2
import multiprocessing

vc=cv2.VideoCapture(0)
face_cascade = cv2.CascadeClassifier('haarcascades/haarcascade_frontalface_default.xml')

pathdir='face/'

personCount = int(raw_input('Kameranın önünde kaç kişi var?'))
for i in range(personCount):
    name = raw_input('Merhaba '+str(i+1)+'. kişinin adını yaz:')
    if not os.path.exists(pathdir+name): os.makedirs(pathdir+name)
    print ( 'Fotoğraf çekmek için hazır mısın? \n')
    print ( ' Eğer yüzün algılandıysa S tuşuna bas ')
    while (1):
        ret,frame = vc.read()

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.2, 7)
        for (x,y,w,h) in faces:
            cv2.rectangle(frame,(x,y),(x+w,y+h),(255,0,0),1)
        cv2.imshow('Yüz Kayıt',frame)
        
        if cv2.waitKey(1) & 0xFF == ord('s'):
            break
    cv2.destroyAllWindows()

    start = time.time()
    count = 0
    while count<50:
        
        ret,frame = vc.read()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.2, 3)
        for (x,y,w,h) in faces:
            cv2.putText(frame,'kaydediliyor..', (x,y-5), cv2.FONT_HERSHEY_COMPLEX_SMALL,1,(0,0,250),1,cv2.LINE_AA)
            count +=1
            cv2.rectangle(frame,(x,y),(x+w,y+h),(255,0,0),1)
            resized_image = cv2.resize(frame[y:y+h,x:x+w], (256, 256))
            print  pathdir+name+'/'+str(time.time())+'.jpg'
            cv2.imwrite( pathdir+name+'/'+str(time.time())+'.jpg', resized_image )
        cv2.imshow('Yüz Kayıt',frame)
        cv2.waitKey(10)
    cv2.destroyAllWindows()
